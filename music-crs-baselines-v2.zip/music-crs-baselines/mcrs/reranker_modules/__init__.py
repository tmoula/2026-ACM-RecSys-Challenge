from .embedding_reranker import EmbeddingReranker


def load_reranker_module(reranker_type: str, **kwargs):
    if reranker_type == "embedding":
        return EmbeddingReranker(**kwargs)
    raise ValueError(f"Unsupported reranker type: {reranker_type}")
