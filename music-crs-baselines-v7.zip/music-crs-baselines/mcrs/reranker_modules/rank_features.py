"""Feature extraction for LambdaMART learning-to-rank."""

from __future__ import annotations

import re
from typing import Dict, List, Optional, Sequence


def _token_set(text: str) -> set[str]:
    return set(re.findall(r"[a-z0-9']+", (text or "").lower()))


def jaccard_similarity(left: str, right: str) -> float:
    left_tokens = _token_set(left)
    right_tokens = _token_set(right)
    if not left_tokens or not right_tokens:
        return 0.0
    intersection = left_tokens & right_tokens
    union = left_tokens | right_tokens
    return len(intersection) / len(union)


def word_overlap_count(left: str, right: str) -> float:
    left_tokens = _token_set(left)
    right_tokens = _token_set(right)
    return float(len(left_tokens & right_tokens))


def build_lambdamart_features(
    candidates: Sequence[str],
    full_query: str,
    dialogue_query: str,
    dense_retriever,
    item_db,
    popularity_scores: Dict[str, float],
) -> List[dict]:
    dense_scores = dense_retriever.score_tracks(full_query, list(candidates))
    user_text = dialogue_query or full_query

    rows: List[dict] = []
    for rank, track_id in enumerate(candidates):
        metadata = item_db.id_to_metadata(track_id)
        rows.append(
            {
                "track_id": track_id,
                "dense_rank": rank,
                "dense_score": dense_scores.get(track_id, 0.0),
                "retrieval_prior": 1.0 / (rank + 1),
                "popularity": popularity_scores.get(track_id, 0.0),
                "text_jaccard": jaccard_similarity(user_text, metadata),
                "word_overlap": word_overlap_count(user_text, metadata),
                "query_len": float(len(_token_set(user_text))),
            }
        )
    return rows


LAMBDAMART_FEATURE_COLUMNS = [
    "dense_rank",
    "dense_score",
    "retrieval_prior",
    "popularity",
    "text_jaccard",
    "word_overlap",
    "query_len",
]
