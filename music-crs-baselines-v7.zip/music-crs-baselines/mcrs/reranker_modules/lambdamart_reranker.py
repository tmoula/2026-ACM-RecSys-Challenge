"""LambdaMART reranker (LightGBM lambdarank) for nDCG@20 optimization."""

import os
from typing import List, Optional

import lightgbm as lgb
import numpy as np

from .rank_features import LAMBDAMART_FEATURE_COLUMNS, build_lambdamart_features
from .rerank_features import load_popularity_scores


class LambdaMARTReRanker:
    """Rerank dense retrieval candidates with a trained LambdaMART model."""

    needs_item_db = True
    needs_retrieval = True

    def __init__(
        self,
        model_path: str = "./cache/reranker/lambdamart_model.txt",
        cache_dir: str = "./cache",
    ) -> None:
        self.model_path = model_path
        self.cache_dir = cache_dir
        self.popularity_scores = load_popularity_scores(cache_dir)
        if not os.path.exists(model_path):
            raise FileNotFoundError(
                f"LambdaMART model not found at {model_path}. "
                "Run build_lambdamart_features.py and train_lambdamart.py first."
            )
        self.model = lgb.Booster(model_file=model_path)

    def _dense_retriever(self, retrieval):
        if hasattr(retrieval, "dense_retriever"):
            return retrieval.dense_retriever
        return retrieval

    def _predict_scores(self, feature_rows: List[dict]) -> np.ndarray:
        matrix = [[row[name] for name in LAMBDAMART_FEATURE_COLUMNS] for row in feature_rows]
        return self.model.predict(matrix)

    def rerank(
        self,
        candidates: List[str],
        user_id: Optional[str] = None,
        topk: int = 20,
        query: Optional[str] = None,
        dialogue_query: Optional[str] = None,
        item_db=None,
        retrieval=None,
        retrieval_meta: Optional[dict] = None,
    ) -> List[str]:
        if not candidates:
            return []

        dense = self._dense_retriever(retrieval)
        full_query = query or dialogue_query or ""
        dialogue_query = dialogue_query or full_query

        feature_rows = build_lambdamart_features(
            candidates=candidates,
            full_query=full_query,
            dialogue_query=dialogue_query,
            dense_retriever=dense,
            item_db=item_db,
            popularity_scores=self.popularity_scores,
        )
        scores = self._predict_scores(feature_rows)
        ranked_indices = np.argsort(-scores)
        reranked = [candidates[index] for index in ranked_indices]

        seen = set(reranked)
        for track_id in candidates:
            if track_id not in seen:
                reranked.append(track_id)
                seen.add(track_id)
        return reranked[:topk]

    def batch_rerank(
        self,
        batch_candidates: List[List[str]],
        user_ids: List[Optional[str]],
        topk: int = 20,
        queries: Optional[List[str]] = None,
        dialogue_queries: Optional[List[str]] = None,
        item_db=None,
        retrieval=None,
    ) -> List[List[str]]:
        return [
            self.rerank(
                candidates,
                user_id=user_id,
                topk=topk,
                query=query,
                dialogue_query=dialogue_query,
                item_db=item_db,
                retrieval=retrieval,
            )
            for candidates, user_id, query, dialogue_query in zip(
                batch_candidates,
                user_ids,
                queries or [None] * len(batch_candidates),
                dialogue_queries or queries or [None] * len(batch_candidates),
            )
        ]
