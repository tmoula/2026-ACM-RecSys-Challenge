from .embedding_reranker import EmbeddingReranker
from .cross_encoder_reranker import CrossEncoderReranker
from .lgbm_reranker import LGBMReranker


def load_reranker_module(reranker_type: str, **kwargs):
    if reranker_type == "embedding":
        return EmbeddingReranker(**kwargs)
    if reranker_type == "cross_encoder":
        return CrossEncoderReranker(**kwargs)
    if reranker_type == "lgbm":
        return LGBMReranker(**kwargs)
    raise ValueError(f"Unsupported reranker type: {reranker_type}")
